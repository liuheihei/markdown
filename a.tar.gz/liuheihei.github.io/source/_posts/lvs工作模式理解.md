layout: lvs
title: LVS 工作模式理解
date: 2016-12-29 18:21:05
tags: "lvs"
comments: true
---
<html>
<head>
<title>2016-12-11-lvs</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
/* GitHub stylesheet for MarkdownPad (http://markdownpad.com) */
/* Author: Nicolas Hery - http://nicolashery.com */
/* Version: b13fe65ca28d2e568c6ed5d7f06581183df8f2ff */
/* Source: https://github.com/nicolahery/markdownpad-github */

/* RESET
=============================================================================*/

html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video {
  margin: 0;
  padding: 0;
  border: 0;
}

/* BODY
=============================================================================*/

body {
  font-family: Helvetica, arial, freesans, clean, sans-serif;
  font-size: 14px;
  line-height: 1.6;
  color: #333;
  background-color: #fff;
  padding: 20px;
  max-width: 960px;
  margin: 0 auto;
}

body>*:first-child {
  margin-top: 0 !important;
}

body>*:last-child {
  margin-bottom: 0 !important;
}

/* BLOCKS
=============================================================================*/

p, blockquote, ul, ol, dl, table, pre {
  margin: 15px 0;
}

/* HEADERS
=============================================================================*/

h1, h2, h3, h4, h5, h6 {
  margin: 20px 0 10px;
  padding: 0;
  font-weight: bold;
  -webkit-font-smoothing: antialiased;
}

h1 tt, h1 code, h2 tt, h2 code, h3 tt, h3 code, h4 tt, h4 code, h5 tt, h5 code, h6 tt, h6 code {
  font-size: inherit;
}

h1 {
  font-size: 28px;
  color: #000;
}

h2 {
  font-size: 24px;
  border-bottom: 1px solid #ccc;
  color: #000;
}

h3 {
  font-size: 18px;
}

h4 {
  font-size: 16px;
}

h5 {
  font-size: 14px;
}

h6 {
  color: #777;
  font-size: 14px;
}

body>h2:first-child, body>h1:first-child, body>h1:first-child+h2, body>h3:first-child, body>h4:first-child, body>h5:first-child, body>h6:first-child {
  margin-top: 0;
  padding-top: 0;
}

a:first-child h1, a:first-child h2, a:first-child h3, a:first-child h4, a:first-child h5, a:first-child h6 {
  margin-top: 0;
  padding-top: 0;
}

h1+p, h2+p, h3+p, h4+p, h5+p, h6+p {
  margin-top: 10px;
}

/* LINKS
=============================================================================*/

a {
  color: #4183C4;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}

/* LISTS
=============================================================================*/

ul, ol {
  padding-left: 30px;
}

ul li > :first-child, 
ol li > :first-child, 
ul li ul:first-of-type, 
ol li ol:first-of-type, 
ul li ol:first-of-type, 
ol li ul:first-of-type {
  margin-top: 0px;
}

ul ul, ul ol, ol ol, ol ul {
  margin-bottom: 0;
}

dl {
  padding: 0;
}

dl dt {
  font-size: 14px;
  font-weight: bold;
  font-style: italic;
  padding: 0;
  margin: 15px 0 5px;
}

dl dt:first-child {
  padding: 0;
}

dl dt>:first-child {
  margin-top: 0px;
}

dl dt>:last-child {
  margin-bottom: 0px;
}

dl dd {
  margin: 0 0 15px;
  padding: 0 15px;
}

dl dd>:first-child {
  margin-top: 0px;
}

dl dd>:last-child {
  margin-bottom: 0px;
}

/* CODE
=============================================================================*/

pre, code, tt {
  font-size: 12px;
  font-family: Consolas, "Liberation Mono", Courier, monospace;
}

code, tt {
  margin: 0 0px;
  padding: 0px 0px;
  white-space: nowrap;
  border: 1px solid #eaeaea;
  background-color: #f8f8f8;
  border-radius: 3px;
}

pre>code {
  margin: 0;
  padding: 0;
  white-space: pre;
  border: none;
  background: transparent;
}

pre {
  background-color: #f8f8f8;
  border: 1px solid #ccc;
  font-size: 13px;
  line-height: 19px;
  overflow: auto;
  padding: 6px 10px;
  border-radius: 3px;
}

pre code, pre tt {
  background-color: transparent;
  border: none;
}

kbd {
    -moz-border-bottom-colors: none;
    -moz-border-left-colors: none;
    -moz-border-right-colors: none;
    -moz-border-top-colors: none;
    background-color: #DDDDDD;
    background-image: linear-gradient(#F1F1F1, #DDDDDD);
    background-repeat: repeat-x;
    border-color: #DDDDDD #CCCCCC #CCCCCC #DDDDDD;
    border-image: none;
    border-radius: 2px 2px 2px 2px;
    border-style: solid;
    border-width: 1px;
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    line-height: 10px;
    padding: 1px 4px;
}

/* QUOTES
=============================================================================*/

blockquote {
  border-left: 4px solid #DDD;
  padding: 0 15px;
  color: #777;
}

blockquote>:first-child {
  margin-top: 0px;
}

blockquote>:last-child {
  margin-bottom: 0px;
}

/* HORIZONTAL RULES
=============================================================================*/

hr {
  clear: both;
  margin: 15px 0;
  height: 0px;
  overflow: hidden;
  border: none;
  background: transparent;
  border-bottom: 4px solid #ddd;
  padding: 0;
}

/* TABLES
=============================================================================*/

table th {
  font-weight: bold;
}

table th, table td {
  border: 1px solid #ccc;
  padding: 6px 13px;
}

table tr {
  border-top: 1px solid #ccc;
  background-color: #fff;
}

table tr:nth-child(2n) {
  background-color: #f8f8f8;
}

/* IMAGES
=============================================================================*/

img {
  max-width: 100%
}
</style>
</head>
<body>
<h3>NAT网络地址转换</h3>
<h5>工作流程</h5>
<pre><code>1.client访问vip.
2.vip将tcp包中的目的地址根据分发策略改变成realserver的ip地址以及端口
    （此时包的源地址为客户端ip地址，目的地址为realserver地址如果需
    要配置iptables需要注意此时包源地址不是lvs的地址所以realserver
    中对应的端口需要开放给所有人）
    (lvs会在自己的应用池里面记录每个包所修改的ip,用于记录当这个包返回时修改为原来的状态)
3.realserver获取到tcp包之后将返回给负载均衡器。
    （出去面试的时候有被问到这个包是怎么回的负载均衡器，需要将realserver的网关指向lvs）
    （此时返回的包源地址为realserver地址，目的地址为客户端地址）
4.vip获取到返回的tcp包之后，修改这个包中的源地址。将realserver的地址转换为vip的地址。
5.客户端收到服务器发回的包。
</code></pre>

<h3>DR模式</h3>
<h5>工作流程</h5>
<pre><code>1.client访问vip
2.vip将tcp包中目的mac地址修改为realserver的mac地址并在局域网内广播。
3.realerver收到广播处理包在将tcp包返回给客户端
</code></pre>

<h3>隧道模式</h3>
<h5>工作流程</h5>
<pre><code>1.client访问vip
2.vip将tcp包再次封装并发送给realserver，
3.realerver收到包后打开封装，发现里面的目的ip就是自己，处理完之后直接发送给客户端。
确实没太理解
</code></pre>

<h3>调度算法</h3>
<h5>轮叫调度（Round-Robin）</h5>
<pre><code>不管服务器当前的连接数和相应速度，所有请求平均分配
</code></pre>

<h5>加权轮叫调度（weighted Round-Robin）</h5>
<pre><code>根据对应的权重表示服务器的处理性能，权重高的优先处理更多的请求
</code></pre>

<h5>最小链接数调度（Least-connection）</h5>
<pre><code>把新请求分配到当前连接数最小的服务器，它通过服务器当前活跃的连接数来估计服务器的负载情况。
</code></pre>

<h5>加权最小链接调度（Weighted Least-Connection）</h5>
<pre><code>把新请求分配给 当前连接数除以权重值最小的服务器，
</code></pre>

<h5>基于局部的最少链接调度（Locality-Based Least Connections ）</h5>
<pre><code>根据目标ip地址找出目标ip地址最近使用过的服务器，
若1.该服务器存活. 
2该服务器没有超载并且没有其他服务器负载小于该服务器二分之一
则选择该服务器，否则选择一个新的服务器处理该请求
</code></pre>

<h5>带复制的基于局部性最小链接调度（Locality-Based Least Connections with Replication Scheduling）</h5>
<pre><code>根据请求目标的IP地址找到对应的服务器组，根据最小链接的原则选择一个服务器组中的服务器，
若服务器没有超载，则将该请求发送到该服务器，若服务器超载则从整个集群中选出一台服务器，
将该服务器加入到服务器组中，并发送请求到该服务器，同时如果服务器组有一段时间没有被修
改（大于设定值）将最忙的服务器从服务器组中剔除，以降低复制的程度。
（cdn可能用处比较多）
</code></pre>

<h5>目标地址散列调度（Destination Hashing Scheduling）</h5>
<h5>源地址散列调度（Source Hashing Scheduling）</h5>
<pre><code>(没太看懂 网站说防火墙集群应用比较多)
</code></pre>

<h5>动态反馈负载均衡算法</h5>
<p><a href="http://www.linuxvirtualserver.org/zh/">LVS中文官网</a>  </p>
<h3>问题：</h3>
<pre><code>1.面试的过程中有被问到，当一个dr模式的lvs依然承受不了压力的时候，怎么办？
我的回答：使用智能dns，将不同区域的请求均衡到不同的lvs机器中去
不过面试官给出的答案是：在交换机层面做什么东西。不过没有细讲解

2.面试过程中问的较多的就是三种工作模式的原理以及每个包到每个服务器时 这个包的目的地址，目的端口，源地址，源端口，以DR、NAT模式居多，这个过程一定要熟悉。
</code></pre>


</body>
</html>
<!-- This document was created with MarkdownPad, the Markdown editor for Windows (http://markdownpad.com) -->
